This is an android application that traces the location of an android application which uses gps services from Google Play Store.

Also please note that parts of this code is taken from the internet and also from Google Android Reference.

This was done as a part of an external and a learning project.
Please do not rely on it. The developers do not take any responsiblity in case of any mishap.
Feel free to fork it and use it for learning puropose.
